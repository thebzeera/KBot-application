// import { Schema } from 'mongoose';

// import { userInfo } from 'os';

const express = require('express');
const bodyParser= require('body-parser')
// const mongoose= require('mongoose')
const MongoClient = require('mongodb').MongoClient
// const dbConfig = require('./db.config.js');
const app = express();

app.use(bodyParser.urlencoded({extended: true}))
app.use(express.static(__dirname + '/css'));
// var db
MongoClient.connect("mongodb://amith:amith123@ds239368.mlab.com:39368/vor", (err,client) => {
  if (err) return console.log(err)
  db = client.db()
  app.listen(3000, () => {
    console.log('listening on 3000')
  })
})

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/registration.html')
    /// Mine was '/Users/zellwk/Projects/demo-repos/crud-express-mongo' for this app.
  })
app.post('/registration', (req, res) => {
  db.collection('user_profile').save(req.body, (err, result) => {
    if (err) return console.log(err)

    console.log('saved to database')
    res.redirect('/')
  })
})


