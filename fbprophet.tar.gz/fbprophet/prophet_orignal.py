import pickle
from fbprophet import Prophet
import numpy as np
import pandas as pd

from matplotlib import pyplot as plt

data_points_per_day=24
tarining_data = .98

load_df = pd.read_csv('cleaned_data.csv')
load_df['ds'] = pd.to_datetime(load_df['ds'])

 # to save a copy of the original data
load_df['y_orig'] = load_df['y']
load_df['y'] = np.log(load_df['y'])



train, test,validate = np.split(load_df, [int(tarining_data*len(load_df)), int(1*len(load_df))])

train.to_csv("train.csv")
model = Prophet() #instantiate Prophet
model.fit(train); #fit the model with your dataframe

future_data = model.make_future_dataframe(periods=int(len(load_df)*(1-tarining_data)),freq='H')
forecast_data = model.predict(future_data)
# model.plot(forecast_data)
model.plot_components(forecast_data)
# plt.show()


model.CalculateAndsetNewBeta()


test = pd.read_csv("test.csv")
fore = model.predict(test)

model.plot_components(fore)
plt.show()


