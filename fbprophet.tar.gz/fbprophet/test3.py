import pickle
from fbprophet import Prophet
import numpy as np
import pandas as pd

from matplotlib import pyplot as plt




A = [[1, 4],
    [-5, 8],
    [3, 5]]

B = [[1],
    [-5],
     [8]]

c=[[3.28571429],
 [0.42857143]]


print(np.matmul(A,c))