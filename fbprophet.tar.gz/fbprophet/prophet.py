import pickle
from collections import OrderedDict

from fbprophet import Prophet
import numpy as np
import pandas as pd
import unknown
from matplotlib import pyplot as plt
#import matplotlib.plot as plt
##
# print("ebnt3er")
extra_regressors = OrderedDict({})
data_points_per_day = 24
tarining_data = .98
load_df = pd.read_csv('future.csv')
load_df['ds'] = pd.to_datetime(load_df['ds'])

 # to save a copy of the original data
# load_df['y_orig'] = load_df['y']
# # log-transform y
# load_df['y'] = np.log(load_df['y'])
#
# #Split data from training and testing
# train, test,validate = np.split(load_df, [int(tarining_data*len(load_df)), int(1*len(load_df))])
#
# history = train[train['y'].notnull()].copy()
#
# history_dates = pd.to_datetime(train['ds']).sort_values()


# def setup_dataframe(self, df, initialize_scales=False):
#     """Prepare dataframe for fitting or predicting.
#
#     Adds a time index and scales y. Creates auxiliary columns 't', 't_ix',
#     'y_scaled', and 'cap_scaled'. These columns are used during both
#     fitting and predicting.
#
#     Parameters
#     ----------
#     df: pd.DataFrame with columns ds, y, and cap if logistic growth. Any
#         specified additional regressors must also be present.
#     initialize_scales: Boolean set scaling factors in self from df.
#
#     Returns
#     -------
#     pd.DataFrame prepared for fitting or predicting.
#     """
#     if 'y' in df:
#         df['y'] = pd.to_numeric(df['y'])
#         if np.isinf(df['y'].values).any():
#             raise ValueError('Found infinity in column y.')
#     df['ds'] = pd.to_datetime(df['ds'])
#     if df['ds'].isnull().any():
#         raise ValueError('Found NaN in column ds.')
#     for name in self.extra_regressors:
#         if name not in df:
#             raise ValueError(
#                 'Regressor "{}" missing from dataframe'.format(name))
#         df[name] = pd.to_numeric(df[name])
#         if df[name].isnull().any():
#             raise ValueError('Found NaN in column ' + name)
#
#     df = df.sort_values('ds')
#     print(df,"dfff")
#     return df

# history = setup_dataframe(history, initialize_scales=True)
        # self.history = history
# start = load_df['ds'].min()
#
# end = load_df['ds'].max()
# t_scale = (end - start)
#
#
# load_df['t'] = load_df['ds'] - start
# t = np.array(load_df['t'])
#
#
#  # to save a copy of the original data
# load_df['y_orig'] = load_df['y']
# # log-transform y
# load_df['y'] = np.log(load_df['y'])
#
#
# #Split data from training and testing
# train, test,validate = np.split(load_df, [int(tarining_data*len(load_df)), int(1*len(load_df))])
# # print(len(train),len(validate),len(test))
#
#
# model = Prophet() #instantiate Prophet
# model.fit(train); #fit the model with your dataframe
# print("enter")
# #print(len(load_df)*(1-tarining_data))
# future_data = model.make_future_dataframe(periods=int(len(load_df)*(1-tarining_data)),freq='H')
#
#
# #forcats data
# forecast_data = model.predict(future_data)
# v    = model.plot_components(forecast_data)
# print(v)
# exit()
dates =load_df['ds']
period = 3
series_order = 3
features = unknown.fourier_series(dates, period, series_order)
# print(features, "features")
# exit()

def make_seasonality_features( dates, period, series_order, prefix='weekly'):
    """Data frame with seasonality features.

    Parameters
    ----------
    cls: Prophet class.
    dates: pd.Series containing timestamps.
    period: Number of days of the period.
    series_order: Number of components.
    prefix: Column name prefix.

    Returns
    -------
    pd.DataFrame with seasonality features.
    """
    features = unknown.fourier_series(dates, period, series_order)
    # print(features,"featuressss")
    columns = [
        '{}_delim_{}'.format(prefix, i + 1)
        for i in range(features.shape[1])
    ]
    return pd.DataFrame(features, columns=columns)


seasonal_features = []
# print(len(dates),"fffff")
make_seasonality_features = make_seasonality_features(dates, period, series_order, prefix='weekly')
seasonal_features.append(make_seasonality_features)
seasonal_featuress = pd.concat(seasonal_features, axis=1)

# +vvvvvvvv")
# print(seasonal_featuress.to_csv("demo.csv"), "vvvvvvvvvvvv")

# seasonal_features.append(make_seasonality_features)
modess = {'additive': ['weekly', 'daily'], 'multiplicative': []}
component_cols, modes = unknown.regressor_column_matrix(
            seasonal_features=seasonal_featuress, modes=modess
        )
# print(component_cols,"compoinenet")
# exit()

# print(len(component_cols[component].values),"component_cols")
# exit()

# lower_p = 100 * (1.0 - self.interval_width) / 2
# upper_p = 100 * (1.0 + self.interval_width) / 2
        # print(component_cols.col,"feturwessss")
        # exit()
X = make_seasonality_features.values
        # seasonal_features.to_csv("gggg.csv")
        # print(seasonal_features,"XXXX")
        # exit()

beta = [[-0.02527481,  0.04915305,  0.0229234,  -0.02436392, -0.00683688,  0.00828509]]

component_modes = {'additive': ['weekly', 'daily', 'US Bank holiday', 'additive_terms', 'extra_regressors_additive', 'holidays'], 'multiplicative': ['multiplicative_terms', 'extra_regressors_multiplicative']}
interval_width = 0.80
data = {}
y_scale = 7.470224135899966
lower_p = 100 * (1.0 - interval_width) / 2
upper_p = 100 * (1.0 + interval_width) / 2
# print(component_cols,"component_cols")
# exit()
for component in component_cols.columns:
    # print(component, "component")
    # print((component_cols[component].values), "component_cols")
    # print(component_modes['additive'], "addictive")
    beta_c = beta * component_cols[component].values

#
    comp = np.matmul(X, beta_c.transpose())
    # print(comp,'comppp')
    if component in component_modes['additive']:
        # print(y_scale,'y_scale')
#
        comp *= y_scale
        data[component] = np.nanmean(comp, axis=1)
        data[component + '_lower'] = np.nanpercentile(
            comp, lower_p, axis=1,
        )
        data[component + '_upper'] = np.nanpercentile(
            comp, upper_p, axis=1,
        )
# print(data,"dta")
# print(pd.DataFrame(data))
seasonal_components = pd.DataFrame(data)
pd.DataFrame(data).to_csv("vv.csv")

# Drop columns except ds, cap, floor, and trend
cols = ['ds']
if 'cap' in load_df:
    cols.append('cap')
# if self.logistic_floor:
#     cols.append('floor')
# Add in forecast components
# print(load_df[cols],"colsss")
df2 = pd.concat((load_df[cols], seasonal_components), axis=1)
df2.to_csv('df.csv')
# print(df2['weekly'][:7], 'df2')
# exit()
v =pd.read_csv('demo.csv')
v['yhat'] = (
    v['trend'] * (1 + 0)
    + v['additive_terms']
)
v['yhat_exp']=np.exp(v['yhat'])
v['yhat_upper_exp']=np.exp(v['yhat_upper'])
v['yhat_lower_exp']=np.exp(v['yhat_lower'])


def plot(
     fcst, ax=None, uncertainty=True, plot_cap=True, xlabel='ds', ylabel='y',
):
    """Plot the Prophet forecast.

    Parameters
    ----------
    m: Prophet model.
    fcst: pd.DataFrame output of m.predict.
    ax: Optional matplotlib axes on which to plot.
    uncertainty: Optional boolean to plot uncertainty intervals.
    plot_cap: Optional boolean indicating if the capacity should be shown
        in the figure, if available.
    xlabel: Optional label name on X-axis
    ylabel: Optional label name on Y-axis

    Returns
    -------
    A matplotlib figure.
    """
    if ax is None:
        fig = plt.figure(facecolor='w', figsize=(10, 6))
        ax = fig.add_subplot(111)
    else:
        fig = ax.get_figure()
    # fcst_t = fcst['ds'].dt.to_pydatetime()
    v =pd.read_csv("history.csv")
    fcst_t = pd.to_datetime(fcst['ds'], errors='coerce')
    ax.plot( pd.to_datetime(v['ds'], errors='coerce'), v['y'], 'k.')
    ax.plot(fcst_t, fcst['yhat'], ls='-', c='#0072B2')
    if 'cap' in fcst and plot_cap:
        ax.plot(fcst_t, fcst['cap'], ls='--', c='k')
    # if m.logistic_floor and 'floor' in fcst and plot_cap:
    #     ax.plot(fcst_t, fcst['floor'], ls='--', c='k')
    # if uncertainty:
    #     ax.fill_between(fcst_t, fcst['yhat_lower'], fcst['yhat_upper'],
    #                     color='#0072B2', alpha=0.2)
    ax.grid(True, which='major', c='gray', ls='-', lw=1, alpha=0.2)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    fig.tight_layout()
    return fig



def seasonality_plot_df( ds):

    """Prepare dataframe for plotting seasonal components.

    Parameters
    ----------
    m: Prophet model.
    ds: List of dates for column ds.

    Returns
    -------
    A dataframe with seasonal components on ds.
    """
    df_dict = {'ds': ds, 'cap': 1., 'floor': 0.}
    # print(m.extra_regressors, "extraa")
    for name in extra_regressors:

        df_dict[name] = 0.
    # print(df_dict,"df_dict")
    df = pd.DataFrame(df_dict)

    return df


def plot_weekly( ax=None, uncertainty=True, weekly_start=0):
    """Plot the weekly component of the forecast.

    Parameters
    ----------
    m: Prophet model.
    ax: Optional matplotlib Axes to plot on. One will be created if this
        is not provided.
    uncertainty: Optional boolean to plot uncertainty intervals.
    weekly_start: Optional int specifying the start day of the weekly
        seasonality plot. 0 (default) starts the week on Sunday. 1 shifts
        by 1 day to Monday, and so on.

    Returns
    -------
    a list of matplotlib artists
    """
    artists = []
    if not ax:
        fig = plt.figure(facecolor='w', figsize=(10, 6))
        ax = fig.add_subplot(111)
    # Compute weekly seasonality for a Sun-Sat sequence of dates.
    days = (pd.date_range(start='2017-01-01', periods=7) +
            pd.Timedelta(days=weekly_start))

    days = days.weekday_name
    artists += ax.plot(list(range(len(days))), df2['weekly'][:7], ls='-',
                       c='#0072B2')
    if uncertainty:
        artists += [ax.fill_between(list(range(len(days))),
                                    df2['weekly_lower'][:7], df2['weekly_upper'][:7],
                                    color='#0072B2', alpha=0.2)]
    ax.grid(True, which='major', c='gray', ls='-', lw=1, alpha=0.2)
    ax.set_xticks(list(range(len(days))))
    ax.set_xticklabels(days)
    ax.set_xlabel('Day of week')
    ax.set_ylabel('weekly')
    return artists


def plot_components(
     fcst, uncertainty=True, plot_cap=True, weekly_start=0, yearly_start=0,
):
    """Plot the Prophet forecast components.

    Will plot whichever are available of: trend, holidays, weekly
    seasonality, yearly seasonality, and additive and multiplicative extra
    regressors.

    Parameters
    ----------
    m: Prophet model.
    fcst: pd.DataFrame output of m.predict.
    uncertainty: Optional boolean to plot uncertainty intervals.
    plot_cap: Optional boolean indicating if the capacity should be shown
        in the figure, if available.
    weekly_start: Optional int specifying the start day of the weekly
        seasonality plot. 0 (default) starts the week on Sunday. 1 shifts
        by 1 day to Monday, and so on.
    yearly_start: Optional int specifying the start day of the yearly
        seasonality plot. 0 (default) starts the year on Jan 1. 1 shifts
        by 1 day to Jan 2, and so on.

    Returns
    -------
    A matplotlib figure.
    """
    # Identify components to be plotted
    components = []
    seasonalities = {'weekly': {'period': 7, 'fourier_order': 3, 'prior_scale': 10.0, 'mode': 'additive'},
     'daily': {'period': 1, 'fourier_order': 4, 'prior_scale': 10.0, 'mode': 'additive'}}

    # print(m.seasonalities,"seasonalitites")
    components.extend([name for name in seasonalities
                    if name in fcst])
    regressors = {'additive': False, 'multiplicative': False}
    extra_regressors = OrderedDict({})
    for name, props in list(extra_regressors.items()):
        regressors[props['mode']] = True
    for mode in ['additive', 'multiplicative']:
        if regressors[mode] and 'extra_regressors_{}'.format(mode) in fcst:
            components.append('extra_regressors_{}'.format(mode))
    npanel = len(components)

    fig, axes = plt.subplots(npanel, 1, facecolor='w',
                            figsize=(9, 3 * npanel))

    if npanel == 1:
        axes = [axes]

    multiplicative_axes = []

    for ax, plot_name in zip(axes, components):

        if plot_name == 'weekly':
            plot_weekly(
                 ax=ax, uncertainty=uncertainty, weekly_start=weekly_start,
            )

        # if plot_name in m.component_modes['multiplicative']:
        #     multiplicative_axes.append(ax)

    fig.tight_layout()
    # Reset multiplicative axes labels after tight_layout adjustment
    # for ax in multiplicative_axes:
    #     ax = set_y_as_percent(ax)
    return fig

c =plot(v)
plot_components(v)




# def plot_components(
#  fcst=df2, uncertainty=True, plot_cap=True, weekly_start=0, yearly_start=0,
# ):
#     """Plot the Prophet forecast components.
#
#     Will plot whichever are available of: trend, holidays, weekly
#     seasonality, yearly seasonality, and additive and multiplicative extra
#     regressors.
#
#     Parameters
#     ----------
#     m: Prophet model.
#     fcst: pd.DataFrame output of m.predict.
#     uncertainty: Optional boolean to plot uncertainty intervals.
#     plot_cap: Optional boolean indicating if the capacity should be shown
#         in the figure, if available.
#     weekly_start: Optional int specifying the start day of the weekly
#         seasonality plot. 0 (default) starts the week on Sunday. 1 shifts
#         by 1 day to Monday, and so on.
#     yearly_start: Optional int specifying the start day of the yearly
#         seasonality plot. 0 (default) starts the year on Jan 1. 1 shifts
#         by 1 day to Jan 2, and so on.
#
#     Returns
#     -------
#     A matplotlib figure.
#     """
#     # Identify components to be plotted
#
#     components = []
#
#     regressors = {'additive': False, 'multiplicative': False}
#     for name, props in list(m.extra_regressors.items()):
#         regressors[props['mode']] = True
#     for mode in ['additive', 'multiplicative']:
#         if regressors[mode] and 'extra_regressors_{}'.format(mode) in fcst:
#             components.append('extra_regressors_{}'.format(mode))
#     npanel = len(components)
#
#     fig, axes = plt.subplots(npanel, 1, facecolor='w',
#                             figsize=(9, 3 * npanel))
#
#     if npanel == 1:
#         axes = [axes]
#
#     multiplicative_axes = []
#
#     for ax, plot_name in zip(axes, components):
#         if plot_name == 'trend':
#             print("dhfgghdf")
#         elif plot_name == 'weekly':
#             plot_weekly(
#                 m=m, ax=ax, uncertainty=uncertainty, weekly_start=weekly_start,
#             )
#
#
#         if plot_name in m.component_modes['multiplicative']:
#             multiplicative_axes.append(ax)
#
#     fig.tight_layout()
#     # Reset multiplicative axes labels after tight_layout adjustment
#     for ax in multiplicative_axes:
#         ax = set_y_as_percent(ax)
#     return fig
#
# def set_y_as_percent(ax):
#     yticks = 100 * ax.get_yticks()
#     yticklabels = ['{0:.4g}%'.format(y) for y in yticks]
#     ax.set_yticklabels(yticklabels)
#     return ax

def seasonality_plot_df( ds):
    """Prepare dataframe for plotting seasonal components.

    Parameters
    ----------
    m: Prophet model.
    ds: List of dates for column ds.

    Returns
    -------
    A dataframe with seasonal components on ds.
    """
    df_dict = {'ds': ds, 'cap': 1., 'floor': 0.}
    # print(m.extra_regressors, "extraa")
    for name in extra_regressors:

        df_dict[name] = 0.
    print(df_dict,"df_dict")
    df = pd.DataFrame(df_dict)
    print(df,"dffff")
    return df



    # print(data,"data")
    # data.to_csv("fff.csv")
    # return pd.DataFrame(data)
# exit()

# def piecewise_linear(t, deltas, k, m, changepoint_ts):
#     """Evaluate the piecewise linear function.
#
#     Parameters
#     ----------
#     t: np.array of times on which the function is evaluated.
#     deltas: np.array of rate changes at each changepoint.
#     k: Float initial rate.
#     m: Float initial offset.
#     changepoint_ts: np.array of changepoint times.
#
#     Returns
#     -------
#     Vector y(t).
#     """
#     # Intercept changes
#     gammas = -changepoint_ts * deltas
#     # Get cumulative slope and intercept at each t
#     k_t = k * np.ones_like(t)
#     m_t = m * np.ones_like(t)
#     for s, t_s in enumerate(changepoint_ts):
#         indx = t >= t_s
#         k_t[indx] += deltas[s]
#         m_t[indx] += gammas[s]
#     return k_t * t + m_t
