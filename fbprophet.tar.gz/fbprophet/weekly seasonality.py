import datetime
from datetime import date
import pandas as pd
import dateutil.parser
df = pd.read_csv("cleaned_data.csv")
df['new_date'] =pd.to_datetime(df['ds']).dt.date
# print (df['new_date'].min())
# df_sort = df.sort_values(['ds', 'y'], ascending=[True, False])
# df['new_date'] = [d.date() for d in df['ds']]
# df_sort =pd.to_datetime(df_sort['ds'], format="%m/%d/%y %H%M")
# ds = df_sort['ds'].dt.date
# print(df_sort['ds'].dt.date)
# d = dateutil.parser.parse(df_sort).date()
# dt = datetime.datetime.strptime(df_sort['ds'], '%m/%d/%y %H:%M')
# dt = df_sort['ds'].apply(lambda x: datetime.strptime(x, '%Y%m%d%H'))
# print(df)
# exit()
df = df.groupby('new_date', as_index=False, sort=False)['y'].mean()
df_sort = df.sort_values(['new_date', 'y'], ascending=[True, False])
# df_min = df.min(df['new_date'])
df['diff'] = df_sort['new_date'] - df.loc[0,'new_date']
df['days'] = df["diff"].dt.days
df['week'] = df['days'].mod(7)
# print(v)
# print(type(df['diff']))
# df['diff'].replace('days'," ")
# print(df['diff'].mod(7))
# df['result'] = df['diff'].map(lambda x: x.rstrip('days'))

# df['delta'] = pd.to_datetime(df['ds']) - pd.to_datetime(df_min)

# df['normalized'] = [i-df.loc[0,'ds'] for i in df['new_date']]
print(df)
li = []
for i in range(0,7):
    sum = df.loc[df['week'] == i, 'y'].sum()
    print(sum)
    average = sum/7
    li.append(average)


print(li)