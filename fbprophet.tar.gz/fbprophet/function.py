from collections import OrderedDict

import numpy as np
import pandas as pd
from matplotlib import pyplot as plt


def fourier_series(dates, period, series_order):
    """Provides Fourier series components with the specified frequency
    and order.

    Parameters
    ----------
    dates: pd.Series containing timestamps.
    period: Number of days of the period.
    series_order: Number of components.

    Returns
    -------
    Matrix with seasonality features.
    """
    # convert to days since epoch
    t = np.array(
        (dates - pd.datetime(1970, 1, 1))
            .dt.total_seconds()
            .astype(np.float)
    ) / (3600 * 24.)
    return np.column_stack([
        fun((2.0 * (i + 1) * np.pi * t / period))
        for i in range(series_order)
        for fun in (np.sin, np.cos)
    ])


def predict_seasonal_components(df):
    """Predict seasonality components, holidays, and added regressors.

    Parameters
    ----------
    df: Prediction dataframe.

    Returns
    -------
    Dataframe with seasonal components.
    """
    seasonal_features, _, component_cols, _ = (
        make_all_seasonality_features(df)
    )
    # print(component_cols, "seasonal_features")
    interval_width = 0.80
    lower_p = 100 * (1.0 - interval_width) / 2
    upper_p = 100 * (1.0 + interval_width) / 2
    X = seasonal_features.values
    beta = [[-0.02527481, 0.04915305, 0.0229234, -0.02436392, -0.00683688, 0.00828509]]
    component_modes = {
        'additive': ['weekly', 'daily', 'US Bank holiday', 'additive_terms', 'extra_regressors_additive', 'holidays'],
        'multiplicative': ['multiplicative_terms', 'extra_regressors_multiplicative']}

    data = {}
    y_scale = 7.470224135899966

    for component in component_cols.columns:
        # print(component_cols,"componenet")
        beta_c = beta * component_cols[component].values
        # print(beta_c,"beta_c")

        comp = np.matmul(X, beta_c.transpose())
        if component in component_modes['additive']:
            # print(self.y_scale,'y_scale')

            comp *= y_scale
        data[component] = np.nanmean(comp, axis=1)
        data[component + '_lower'] = np.nanpercentile(
            comp, lower_p, axis=1,
        )
        data[component + '_upper'] = np.nanpercentile(
            comp, upper_p, axis=1,
        )

    return pd.DataFrame(data)


def add_group_component(components, name, group):
    """Adds a component with given name that contains all of the components
    in group.

    Parameters
    ----------
    components: Dataframe with components.
    name: Name of new group component.
    group: List of components that form the group.

    Returns
    -------
    Dataframe with components.
    """
    new_comp = components[components['component'].isin(set(group))].copy()
    group_cols = new_comp['col'].unique()
    if len(group_cols) > 0:
        new_comp = pd.DataFrame({'col': group_cols, 'component': name})
        components = components.append(new_comp)
    return components


def regressor_column_matrix(seasonal_features, modes):
    """Dataframe indicating which columns of the feature matrix correspond
    to which seasonality/regressor components.

    Includes combination components, like 'additive_terms'. These
    combination components will be added to the 'modes' input.

    Parameters
    ----------
    seasonal_features: Constructed seasonal features dataframe
    modes: Dictionary with keys 'additive' and 'multiplicative' listing the
        component names for each mode of seasonality.

    Returns
    -------
    component_cols: A binary indicator dataframe with columns seasonal
        components and rows columns in seasonal_features. Entry is 1 if
        that columns is used in that component.
    modes: Updated input with combination components.
    """
    # print(seasonal_features.columns,"seasona")
    components = pd.DataFrame({
        'col': np.arange(seasonal_features.shape[1]),
        'component': [
            x.split('_delim_')[0] for x in seasonal_features.columns
        ],
    })
    print(components, "seasona")

    # Add totals additive and multiplicative components, and regressors
    extra_regressors = OrderedDict({})
    for mode in ['additive', 'multiplicative']:
        components = add_group_component(
            components, mode + '_terms', modes[mode]
        )
        regressors_by_mode = [
            r for r, props in list(extra_regressors.items())
            if props['mode'] == mode
        ]
        components = add_group_component(
            components, 'extra_regressors_' + mode, regressors_by_mode)
        # Add combination components to modes
        modes[mode].append(mode + '_terms')
        modes[mode].append('extra_regressors_' + mode)

    # Convert to a binary matrix
    component_cols = pd.crosstab(
        components['col'], components['component'],
    ).sort_index(level='col')
    # Add columns for additive and multiplicative terms, if missing
    for name in ['additive_terms', 'multiplicative_terms']:
        if name not in component_cols:
            component_cols[name] = 0
    # Remove the placeholder
    component_cols.drop('zeros', axis=1, inplace=True, errors='ignore')
    # Validation
    if (
            max(component_cols['additive_terms']
                + component_cols['multiplicative_terms']) > 1
    ):
        raise Exception('A bug occurred in seasonal components.')
    # Compare to the training, if set.

    return component_cols, modes


def make_all_seasonality_features(df):
    """Dataframe with seasonality features.

    Includes seasonality features, holiday features, and added regressors.

    Parameters
    ----------
    df: pd.DataFrame with dates for computing seasonality features and any
        added regressors.

    Returns
    -------
    pd.DataFrame with regression features.
    list of prior scales for each column of the features dataframe.
    Dataframe with indicators for which regression components correspond to
        which columns.
    Dictionary with keys 'additive' and 'multiplicative' listing the
        component names for each mode of seasonality.
    """
    seasonal_features = []
    prior_scales = []
    modes = {'additive': [], 'multiplicative': []}
    # Seasonality features
    features = make_seasonality_features(df['ds'], period=3, series_order=3, prefix='weekly')

    print(type(features), "fetu")

    seasonal_features.append(features)
    # print(type(seasonal_features))
    seasonal_features = pd.concat(seasonal_features, axis=1)

    # print(seasonal_features.to_csv("kk.csv"),"feee")
    component_cols, modes = regressor_column_matrix(
        seasonal_features, modes
    )
    return seasonal_features, prior_scales, component_cols, modes


def make_seasonality_features(dates, period, series_order, prefix='weekly'):
    """Data frame with seasonality features.

    Parameters
    ----------
    cls: Prophet class.
    dates: pd.Series containing timestamps.
    period: Number of days of the period.
    series_order: Number of components.
    prefix: Column name prefix.

    Returns
    -------
    pd.DataFrame with seasonality features.
    """
    features = fourier_series(dates, period, series_order)
    # print(features,"featuressss")
    columns = [
        '{}_delim_{}'.format(prefix, i + 1)
        for i in range(features.shape[1])
    ]
    return pd.DataFrame(features, columns=columns)


def seasonality_plot_df(ds):
    """Prepare dataframe for plotting seasonal components.

    Parameters
    ----------
    m: Prophet model.
    ds: List of dates for column ds.

    Returns
    -------
    A dataframe with seasonal components on ds.
    """
    df_dict = {'ds': ds, 'cap': 1., 'floor': 0.}
    # print(m.extra_regressors, "extraa")

    df = pd.DataFrame(df_dict)

    print(df, "dff")
    return df


def plot_weekly( ax=None, uncertainty=True, weekly_start=0):
    """Plot the weekly component of the forecast.

    Parameters
    ----------
    m: Prophet model.
    ax: Optional matplotlib Axes to plot on. One will be created if this
        is not provided.
    uncertainty: Optional boolean to plot uncertainty intervals.
    weekly_start: Optional int specifying the start day of the weekly
        seasonality plot. 0 (default) starts the week on Sunday. 1 shifts
        by 1 day to Monday, and so on.

    Returns
    -------
    a list of matplotlib artists
    """
    artists = []
    if not ax:
        fig = plt.figure(facecolor='w', figsize=(10, 6))
        ax = fig.add_subplot(111)
    # Compute weekly seasonality for a Sun-Sat sequence of dates.
    days = (pd.date_range(start='2017-01-01', periods=7) +
            pd.Timedelta(days=weekly_start))
    print(days,"days")
    df_w = seasonality_plot_df(days)
    seas = predict_seasonal_components(df_w)
    days = days.weekday_name
    artists += ax.plot(list(range(len(days))), seas['weekly'], ls='-',
                    c='#0072B2')
    if uncertainty:
        artists += [ax.fill_between(list(range(len(days))),
                                    seas['weekly_lower'], seas['weekly_upper'],
                                    color='#0072B2', alpha=0.2)]
    ax.grid(True, which='major', c='gray', ls='-', lw=1, alpha=0.2)
    ax.set_xticks(list(range(len(days))))
    ax.set_xticklabels(days)
    ax.set_xlabel('Day of week')
    ax.set_ylabel('weekly')
    # if m.seasonalities['weekly']['mode'] == 'multiplicative':
    #     ax = set_y_as_percent(ax)
    # print(artists,"artist")
    return artists


def plot_components(
     fcst, uncertainty=True, plot_cap=True, weekly_start=0, yearly_start=0,
):
    """Plot the Prophet forecast components.

    Will plot whichever are available of: trend, holidays, weekly
    seasonality, yearly seasonality, and additive and multiplicative extra
    regressors.

    Parameters
    ----------
    m: Prophet model.
    fcst: pd.DataFrame output of m.predict.
    uncertainty: Optional boolean to plot uncertainty intervals.
    plot_cap: Optional boolean indicating if the capacity should be shown
        in the figure, if available.
    weekly_start: Optional int specifying the start day of the weekly
        seasonality plot. 0 (default) starts the week on Sunday. 1 shifts
        by 1 day to Monday, and so on.
    yearly_start: Optional int specifying the start day of the yearly
        seasonality plot. 0 (default) starts the year on Jan 1. 1 shifts
        by 1 day to Jan 2, and so on.

    Returns
    -------
    A matplotlib figure.
    """
    # Identify components to be plotted
    components = []
    seasonalities = {'weekly': {'period': 7, 'fourier_order': 3, 'prior_scale': 10.0, 'mode': 'additive'},
     'daily': {'period': 1, 'fourier_order': 4, 'prior_scale': 10.0, 'mode': 'additive'}}

    # print(m.seasonalities,"seasonalitites")
    components.extend([name for name in seasonalities
                    if name in fcst])
    regressors = {'additive': False, 'multiplicative': False}
    extra_regressors = OrderedDict({})
    for name, props in list(extra_regressors.items()):
        regressors[props['mode']] = True
    for mode in ['additive', 'multiplicative']:
        if regressors[mode] and 'extra_regressors_{}'.format(mode) in fcst:
            components.append('extra_regressors_{}'.format(mode))
    npanel = len(components)

    fig, axes = plt.subplots(npanel, 1, facecolor='w',
                            figsize=(9, 3 * npanel))

    if npanel == 1:
        axes = [axes]

    multiplicative_axes = []

    for ax, plot_name in zip(axes, components):

        if plot_name == 'weekly':
            plot_weekly(
                 ax=ax, uncertainty=uncertainty, weekly_start=weekly_start,
            )

        # if plot_name in m.component_modes['multiplicative']:
        #     multiplicative_axes.append(ax)

    fig.tight_layout()
    # Reset multiplicative axes labels after tight_layout adjustment
    # for ax in multiplicative_axes:
    #     ax = set_y_as_percent(ax)
    return fig

