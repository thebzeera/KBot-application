A search engine for textfiles. Made on a plane flight.
