import buildindex
import re


# input = [file1, file2, ...]
# res = {word: {filename: {pos1, pos2}, ...}, ...}
class Query:
    def __init__(self, filenames):
        """

        :param filenames: file names
        """
        self.temp=[]
        self.filenames = filenames
        self.index = buildindex.BuildIndex(self.filenames)
        self.invertedIndex = self.index.totalIndex
        self.regularIndex = self.index.regdex

    def one_word_query(self, word):
        """

        :param word: words
        :return:
        """
        pattern = re.compile('[\W_]+')
        word = pattern.sub(' ', word)
        if word in self.invertedIndex.keys():

            return self.rankResults([filename for filename in self.invertedIndex[word].keys()], word)
        else:
            return []

    def phrase_query(self, string):
        """

        :param string: set of words
        :return:
        """
        listoflists = []
        listoflist = {}
        pattern = re.compile('[\W_]+')
        string = pattern.sub(' ', string)
        listsofsearch = []
        for word in string.split():
            oneword = self.one_word_query(word)
            listsofsearch.append(self.one_word_query(word))
            listoflist[oneword[0][1]] = oneword[0][0]
        for key in listoflist.keys():
            listoflists.append(key)
        for filename in listoflists:
            tempforfile = []
            for word in string.split():
                if word in self.invertedIndex.keys():
                    worddict = self.invertedIndex[word]
                    if filename in worddict.keys():
                        tempforfile.append(self.invertedIndex[word][filename][:])
        finalresult = self.rankResults(listoflists, string)
        for i in range(len(finalresult)):
            return (finalresult[i][1])

    def make_vectors(self, documents):
        """

        :param documents: file names
        :return:
        """
        vecs = {}
        for doc in documents:

            docVec = [0] * len(self.index.getUniques())
            for ind, term in enumerate(self.index.getUniques()):
                docVec[ind] = self.index.generateScore(term, doc)
            vecs[doc] = docVec
        return vecs

    def query_vec(self, query):
        """

        :param query: query
        :return:
        """
        pattern = re.compile('[\W_]+')
        query = pattern.sub(' ', query)
        queryls = query.split()
        queryVec = [0] * len(queryls)
        index = 0
        for ind, word in enumerate(queryls):
            queryVec[index] = self.queryFreq(word, query)
            index += 1
        queryidf = [self.index.idf[word] for word in self.index.getUniques()]

        magnitude = pow(sum(map(lambda x: x ** 2, queryVec)), .5)
        freq = self.termfreq(self.index.getUniques(), query)
        tf = [x / magnitude for x in freq]
        final = [tf[i] * queryidf[i] for i in range(len(self.index.getUniques()))]
        return final

    def queryFreq(self, term, query):
        """

        :param term: term
        :param query: query
        :return:
        """
        count = 0
        for word in query.split():
            if word == term:
                count += 1
        return count

    def termfreq(self, terms, query):
        """

        :param terms: terms
        :param query:query
        :return:
        """
        temp = [0] * len(terms)
        for i, term in enumerate(terms):
            temp[i] = self.queryFreq(term, query)
        return temp

    def dotoduct(self, doc1, doc2):
        """

        :param doc1:doc 1
        :param doc2: doc 2
        :return:
        """
        if len(doc1) != len(doc2):
            return 0
        return sum([x * y for x, y in zip(doc1, doc2)])

    def rankResults(self, resultDocs, query):
        """

        :param resultDocs:file name
        :param query: query
        :return:
        """
        vectors = self.make_vectors(resultDocs)
        queryVec = self.query_vec(query)
        results = [[self.dotoduct(vectors[result], queryVec), result] for result in resultDocs]
        results.sort(key=lambda x: x[0])
        results = [x[1] for x in results]
        return self.fetching_result(results, query)

    def fetching_result(self, result, word):
        """

        :param result: result
        :param word: word
        :return:
        """
        for file in result:
            err_occur = []
            substr = word
            try:
                with open(file, 'rt') as in_file:
                    for linenum, line in enumerate(in_file):
                        if line.lower().find(substr) != -1:
                            err_occur.append((linenum, line.rstrip(
                                '\n')))
                    for linenum, line in err_occur:
                        print("Line ", linenum, ": ", line, sep='')
            except FileNotFoundError:
                print("Log file not found.")
