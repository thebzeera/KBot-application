from querytexts import Query

q = Query(['pg135.txt','pg76.txt', 'pg5200.txt'])
q.one_word_query("facil")

