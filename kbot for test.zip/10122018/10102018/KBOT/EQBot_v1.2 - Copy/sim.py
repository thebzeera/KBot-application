import re, math
from collections import Counter

WORD = re.compile(r'\w+')

def get_cosine(vec1, vec2):
     intersection = set(vec1.keys()) & set(vec2.keys())
     numerator = sum([vec1[x] * vec2[x] for x in intersection])

     sum1 = sum([vec1[x]**2 for x in vec1.keys()])
     sum2 = sum([vec2[x]**2 for x in vec2.keys()])
     denominator = math.sqrt(sum1) * math.sqrt(sum2)

     if not denominator:
        return 0.0
     else:
        return float(numerator) / denominator

def text_to_vector(text):
     words = WORD.findall(text)
     return Counter(words)

text1 = 'what is equifax?'
text2 = 'The contents of this document are confidential and proprietary to Equifax Inc. and may not be reproduced, published, or disclosed to others without written authorization of Equifax Inc. Any other use, including reproduction in whole or in part, distribution to outside third parties, or sale of the contents without prior written consent from Equifax Inc. is PROHIBITED. Unauthorized or improper access to the system, unauthorized disclosure of confidential codes or system access instructions, or intentional alteration or destruction of data can lead to federal prosecution under the Counterfeit Access Device and Computer Fraud and Abuse Act'

vector1 = text_to_vector(text1)
vector2 = text_to_vector(text2)

cosine = get_cosine(vector1, vector2)

print ( cosine)
def symmetric_sentence_similarity(sentence1, sentence2):
    
    return (sentence_similarity(sentence1, sentence2) + sentence_similarity(sentence2, sentence1)) 
def penn_to_wn(tag):
    
    if tag.startswith('N'):
        return 'n'
 
    if tag.startswith('V'):
        return 'v'
 
    if tag.startswith('J'):
        return 'a'
 
    if tag.startswith('R'):
        return 'r'
 
    return None
 
def tagged_to_synset(word, tag):
    wn_tag = penn_to_wn(tag)
    if wn_tag is None:
        return None
 
    try:
        return wn.synsets(word, wn_tag)[0]
    except:
        return None
 
def sentence_similarity(sentence1, sentence2):
    
   
    sentence1 = pos_tag(word_tokenize(sentence1))
    sentence2 = pos_tag(word_tokenize(sentence2))
 
   
    synsets1 = [tagged_to_synset(*tagged_word) for tagged_word in sentence1]
    synsets2 = [tagged_to_synset(*tagged_word) for tagged_word in sentence2]
 
    
    synsets1 = [ss for ss in synsets1 if ss]
    synsets2 = [ss for ss in synsets2 if ss]
 
    score, count = 0.0, 0
    
    
    for synset in synsets1:
        
        high= [synset.path_similarity(ss) for ss in synsets2 if synset.path_similarity(ss)!=None]
        best_score=0
       

        if len(high) !=0 :
            
                
                best_score = max(high)
 
        
        if best_score is not None:
            score += best_score
            count += 1
 
    
    if count > 0 :
        score /= count
    return score