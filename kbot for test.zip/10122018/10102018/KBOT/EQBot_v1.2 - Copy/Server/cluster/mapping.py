import os
import spacy

def mapping(file):
    """

        :param file: path of the dataset directory
        :return: JSON file
        """
    file_path=file

    with open('json/filesearch.json', 'w', )as json_file:
        print('')

    for i in file_path:
        add_slash = os.path.join(i, '', '')
        for filename in os.listdir(i):
            file_path = add_slash + filename
            with open(file_path, 'r') as text:
                text=text.read()
                nlp = spacy.load('en_coref_md')
                doc = nlp(text)
                doc_coref=doc._.coref_resolved
                print(doc_coref)