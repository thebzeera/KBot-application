import pickle
from fbprophet import Prophet
import numpy as np
import pandas as pd
import unknown
from matplotlib import pyplot as plt
#import matplotlib.plot as plt
##
data_points_per_day = 24
tarining_data = .98
load_df = pd.read_csv('cleaned_data.csv')
load_df['ds'] = pd.to_datetime(load_df['ds'])
start = load_df['ds'].min()
from datetime import timedelta
# v=timedelta(start)
# print(v)
end = load_df['ds'].max()
t_scale = (end - start)


# print(type(end))
# t_scale = (end - start).seconds
# print(type(t_scale))

from datetime import date
# scale = date.fromtimestamp(t_scale)
# print(type(start))
# t_scale = load_df['ds'].max()-start
# print(type(t_scale))
import datetime as dt
load_df['t'] = load_df['ds'] - start
t = np.array(load_df['t'])
#
#
# k = np.nanmean(unknown.params['k'])
#
# m = np.nanmean(unknown.params['m'])
#
# deltas = np.nanmean(unknown.params['delta'], axis=0)
#
# t = np.array(load_df['t'])
# #
# changepoints_t = np.array([5])
# trend = unknown.piecewise_linear(t, unknown.deltas, unknown.k, unknown.m, unknown.changepoints_t)
# unknown.plot_forecast_component(trend)
# # # # print(load_df)
# #
# exit()
holidays = pd.DataFrame({
    'holiday': 'US Bank holiday',
    'ds'     : pd.to_datetime(['2017-01-02'
                               ,'2017-01-16'
                               ,'2017-02-20'
                               ,'2017-05-29'
                               ,'2017-07-04'
                               ,'2017-09-04'
                               ,'2017-11-11'
                               ,'2017-11-23'
                               ,'2017-12-25'])
})


 # to save a copy of the original data
load_df['y_orig'] = load_df['y']
# log-transform y
load_df['y'] = np.log(load_df['y'])


#Split data from training and testing
train, test,validate = np.split(load_df, [int(tarining_data*len(load_df)), int(1*len(load_df))])
# print(len(train),len(validate),len(test))


model = Prophet(holidays=holidays,yearly_seasonality=False) #instantiate Prophet
model.fit(train); #fit the model with your dataframe

#print(len(load_df)*(1-tarining_data))
future_data = model.make_future_dataframe(periods=int(len(load_df)*(1-tarining_data)),freq='H')


#forcats data
forecast_data = model.predict(future_data)
model.plot_components(forecast_data)


# def piecewise_linear(t, deltas, k, m, changepoint_ts):
#     """Evaluate the piecewise linear function.
#
#     Parameters
#     ----------
#     t: np.array of times on which the function is evaluated.
#     deltas: np.array of rate changes at each changepoint.
#     k: Float initial rate.
#     m: Float initial offset.
#     changepoint_ts: np.array of changepoint times.
#
#     Returns
#     -------
#     Vector y(t).
#     """
#     # Intercept changes
#     gammas = -changepoint_ts * deltas
#     # Get cumulative slope and intercept at each t
#     k_t = k * np.ones_like(t)
#     m_t = m * np.ones_like(t)
#     for s, t_s in enumerate(changepoint_ts):
#         indx = t >= t_s
#         k_t[indx] += deltas[s]
#         m_t[indx] += gammas[s]
#     return k_t * t + m_t
