import tika
from tika import parser
import os
import requests
import glob
from os import path

os.environ['NO_PROXY'] = 'localhost'
session = requests.Session()
session.trust_env = False
# tika.TikaClientOnly = True
# tika.tika.TIKA_SERVER_ENDPOINT = 'http://127.0.0.1:9998'
# tika.tika.TIKA_PATH = 'C:\\installs\\pylibs\\tika\\server'
# tika.tika.TIKA_LOG_PATH = 'C:\\installs\\pylibs\\tika\\logs'
# parsed = parser.from_file('C:\\Documents\\forBot\\1.CMS Fusion Introduction.docx')
# parsed = parser.from_file('C:\\Documents\\forBot\\j2m-shareable.jpg')
# print(parsed["content"])
# print(parsed["metadata"])
import os

from PyPDF2 import PdfFileReader,PdfFileWriter

# creating a pdf file object
# pdfFileObj = open('example.pdf', 'rb')

# creating a pdf reader object
# pdfReader = PyPDF2.PdfFileReader(pdfFileObj)
basepath = path.dirname(__file__)
trim = basepath.split("dataSetup")[0]
full_path = trim + 'Server/cluster/test_tika'
file_list = []
for root, dirs, files in os.walk(full_path):
    file_list.append(root)

file = []
for f in file_list:
    for filename in os.listdir(f):
        add_slash = os.path.join(str(f), '')
        file_path = add_slash + filename
        file.append(file_path)

genPath = trim + "Server/cluster/test"
# print(file)
i = 0
for name in file:
    # pdfFileObj = open(name, 'rb')
    # print(pdfFileObj)
    # exit()
    # input1 = PyPDF2.PdfFileReader(open("01_IJRG17_A06_327.pdf", "rb"))
    # pdf_in_file = open("07chapter1.pdf", 'rb')
    pdf_in_file = open("1-120-142781024201-05.pdf", 'rb')

    inputpdf = PdfFileReader(pdf_in_file)

    pages_no = inputpdf.numPages

    for i in range(pages_no):
        inputpdf = PdfFileReader(pdf_in_file)
        output = PdfFileWriter()
        output.addPage(inputpdf.getPage(i))
        with open("dfdg-page%s.pdf" % i, "wb") as outputStream:
            output.write(outputStream)

    pdf_in_file.close()
    parsed = parser.from_file('dfdg-page0.pdf')
    fh = open("pppp", "w", encoding='utf8')
    fh.write(name + parsed["content"])
    # parsed = parser.from_file(input1)
    # pdfReader = PyPDF2.PdfFileReader(pdfFileObj)
    # print(pdfReader)

    # if os.path.isfile(name):
    #
    #     ext = [".doc", ".docx", ".pdf", ".ppt", ".pptx", ".xls", ".xlsx"]
    #
    #     genPath = trim + "Server/cluster/test"
    #     try:
    #         parsed = parser.from_file(name)
    #         print(name)
    #         fh = open(genPath + '/' + str(i + 1) + '.txt', "w", encoding='utf8')
    #         fh.write(name + parsed["content"])
    #         fh.close()
    #         i += 1
    #     except:
    #         print("exception for : " + name)