
import os
import glob


files = glob.glob('txtToJSON/genJson/*')
for f in files:
    os.remove(f)
os.system('python txtToJSON/txtToJSON.py')


path ='txtToJSON/genJson/*.json'
files = glob.glob(path)
i=0
for name in files:
    print (name);
    os.system('mongoimport --db    vor -c    filesearch --file '+name);

print ( "Done exporting Documents to MongoDB");
os.system('mongoexport  --db vor -c filesearch  -o cluster/filesearch.json');

#os.system('python ImportData.py');
#print ("ID.txt generated");
#os.system('mongoimport  --db vor -c TFIDFtest  --file TFIDF.json');
#print ( "exported TFIDF.json to MongoDb");
#print ( "starting server");
#os.system('python pymongotestd_w.py');