import numpy as np
x = np.linspace(-5, 5, 1000)
print(x)