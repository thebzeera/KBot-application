import pandas as pd
import linear_regression
import numpy as np
from matplotlib import pyplot as plt


def find_beta(X, comp):
    # comp = np.matmul(X, beta_c.transpose())
    y_scale = 7.4702241
    sd=X.shape
    # print(comp)
    comp=comp/y_scale
    # print(comp)
    temp1 = np.random.rand(14, 7)
    newcomb = np.matmul(temp1, comp)
    newX = np.matmul(temp1, X)
    inveres = np.linalg.inv(newX)
    print(newX.shape,"nex")
    newbeta = np.matmul(inveres, newcomb)
    # newbeta=1223

    return newbeta




    # plt.plot(newbeta)
    # plt.plot(beta_c.transpose())

# dict = {"comp":[-0.7061418326647038,-0.21504899338431424,0.30783108182459057,0.2264733844582165,0.25359067048089756,0.2251252629417332,-0.09182957365782718]}
# comp = [-0.7061418326647038,-0.21504899338431424,0.30783108182459057,0.2264733844582165,0.25359067048089756,0.2251252629417332,-0.09182957365782718]

c = pd.read_csv("X_weekly.csv")
comp = pd.read_csv("compsasa_weekly.csv")
week = comp['weekly']
print(week.shape)
obj = find_beta(c, week)
X = pd.read_csv('WeeklX.csv')
comp = pd.read_csv('Weeklcomp.csv')
Beta = pd.read_csv('WeeklBeta.csv')
# X.drop(['Unnamed:0'],axis=1)


temp1=np.random.rand(X.shape[1],X.shape[0])
newcomb=np.matmul(temp1,comp)
newX=np.matmul(temp1, X)
inveres=np.linalg.inv(newX)
newbeta=np.matmul(inveres,newcomb)
print(newbeta,'newbeta')



