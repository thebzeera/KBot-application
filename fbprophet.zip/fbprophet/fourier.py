import pandas as pd
import numpy as np
from matplotlib import pyplot as plt


def fourier_series(dates, period, series_order):



    return np.column_stack([
        fun((2.0 * (i + 1) * np.pi * t / period))
        for i in range(series_order)
        for fun in (np.sin, np.cos)
    ])


data = pd.read_csv('futurre.csv', parse_dates=['ds'])
dates = data['ds']

fourier = fourier_series(dates, period=7, series_order=3)

prefix = 'weekly'
columns = [
            '{}_delim_{}'.format(prefix, i + 1)
            for i in range(fourier.shape[1])
        ]

weekly_feature = pd.DataFrame(fourier, columns=columns)
weekly_feature.to_csv("weekly_features.csv")

beta = np.zeros(weekly_feature.shape[1])
print(beta.reshape(1, -1))
floor = 0.0

beta = np.random.normal(size=2 * 3)

# beta = np.random.normal(size=2 * n)
plt.figure(figsize=(16, 6))
plt.plot(fourier @ beta)
plt.show()

y_scale = (data['y'] - floor).abs().max()

