import time

import  pandas as pd
import numpy as np

data = pd.read_csv("cleaned_data.csv")
data['ds'] = pd.to_datetime(data['ds'], errors='coerce')
s =[]
for dt in data['ds']:
    v = dt.hour * 3600 + dt.minute * 60 + dt.second
    s.append(v)
print(len(s))

exit()
# data['ds'] = (data['ds'] - pd.datetime(1970, 1, 1)).dt.total_seconds().astype(np.float)
# data['seconds'] = [time.mktime(t.timetuple()) for t in data.datetime]
# print(date)
# exit()
data.set_index('ds', inplace=True)
weeks = [g for n, g in data.groupby(pd.TimeGrouper('W'))]
# for i in weeks:
#     print((i['ds']))
#     print("***********************")


from datetime import datetime, date, time

def avg_time(datetimes):
    total = sum(dt.hour * 3600 + dt.minute * 60 + dt.second for dt in datetimes)
    print(total)
    avg = total / len(datetimes)
    minutes, seconds = divmod(int(avg), 60)
    hours, minutes = divmod(minutes, 60)
    return datetime.combine(date(1900, 1, 1), time(hours, minutes, seconds))

v = avg_time(data['ds'])
# for n, g in data.groupby(pd.TimeGrouper('W')):
    # print((n))
    # print(g)
    # data['ds'] = (data['ds'] - pd.datetime(1970, 1, 1)).dt.total_seconds().astype(np.float)

# df = pd.DataFrame({'col':weeks})
# print (df)
# exit()
# data['ds'] = (data['ds'] - pd.datetime(1970, 1, 1)).dt.total_seconds().astype(np.float)
# print((weeks['ds']),"wekke")
# date = weeks['ds'].dt.to_pydatetime()
# print(date)
# print(weeks)