
import  pandas as pd
import linear_regression

def Preict_after_change(Yscale):
    change_Y_Value=pd.read_csv("seas.csv")
    change_Y_Value/=y_scale
    # Generate X
    X=[1,2,3,4,6]
    Beta_C=linear_regression(X,change_Y_Value)
    return Beta_C

