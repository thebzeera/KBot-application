import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# df = pd.read_csv("cleaned_data.csv")
# x_a = np.arange(len(df['ds']))
# x_b = df['y'].values
# x_a =[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25]
# x_b = [10,12,20,22,21,25,30,21,32,34,35,30,50,45,55,60,66,64,67,72,74,80,79,84]
x_a = [2, 3, 4]
x_b = [10, 12, 3]
x_a =np.array(x_a)
x_b = np.array(x_b)
print(((np.mean(x_a)*np.mean(x_a))-np.mean(x_a*x_a)),"c")
print(((np.mean(x_a)*np.mean(x_b))-np.mean(x_a*x_b)),"b")
m = (((np.mean(x_a)*np.mean(x_b))-np.mean(x_a*x_b))/((np.mean(x_a)*np.mean(x_a))-np.mean(x_a*x_a)))
print(m,"a")
print(((np.mean(x_a)*np.mean(x_a))-np.mean(x_a*x_a))*(((np.mean(x_a)*np.mean(x_b))-np.mean(x_a*x_b))/((np.mean(x_a)*np.mean(x_a))-np.mean(x_a*x_a))))
# exit()

def slope(x_a, x_b):
    x_a =np.array(x_a)
    x_b = np.array(x_b)
    m = (((np.mean(x_a)*np.mean(x_b))-np.mean(x_a*x_b))/((np.mean(x_a)*np.mean(x_a))-np.mean(x_a*x_a)))
    b = (np.mean(x_b)-np.mean(x_a)*m)
    m = round(m, 2)
    b = round(b, 2)
    return m, b

m, b = slope(x_a,x_b)
print(m,b)
# v = m.tolist()
# print(type(x_a))
# print(m*x_a)
# exit()
# exit()
# for x in x_a:
#     reg_line=int(m)*x_a+b


reg_line = [(m*x)+b for x in x_a]
# print(reg_line)
# exit()
plt.scatter(x_a, x_b,color='red')
plt.plot(x_a, reg_line)
plt.show()

