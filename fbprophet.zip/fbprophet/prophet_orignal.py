import pickle
from fbprophet import Prophet
import numpy as np
import pandas as pd
#import matplotlib.plot as plt
##
data_points_per_day=24
tarining_data = .98

load_df = pd.read_csv('cleaned_data.csv')
load_df['ds'] = pd.to_datetime(load_df['ds'])


holidays = pd.DataFrame({
    'holiday': 'US Bank holiday',
    'ds'     : pd.to_datetime( ['2017-01-02'
                               ,'2017-01-16'
                               ,'2017-02-20'
                               ,'2017-05-29'
                               ,'2017-07-04'
                               ,'2017-09-04'
                               ,'2017-11-11'
                               ,'2017-11-23'
                               ,'2017-12-25'] )
})

 # to save a copy of the original data
load_df['y_orig'] = load_df['y']
# log-transform y
load_df['y'] = np.log(load_df['y'])

#Split data from training and testing
train, test,validate = np.split(load_df, [int(tarining_data*len(load_df)), int(1*len(load_df))])
# print(len(train),len(validate),len(test))

model = Prophet(holidays=holidays) #instantiate Prophet
model.fit(train); #fit the model with your dataframe

#print(len(load_df)*(1-tarining_data))
future_data = model.make_future_dataframe(periods=int(len(load_df)*(1-tarining_data)),freq='H')
# print(future_data,)
future_data.to_csv("futurre.csv")
# exit()
# forcats data
forecast_data = model.predict(future_data)
v = pd.read_csv('original.csv')
# exit()
#inverse log of yhat
v['yhat_exp']=np.exp(v['yhat'])
# forecast_data['yhat_upper_exp']=np.exp(forecast_data['yhat_upper'])
# forecast_data['yhat_lower_exp']=np.exp(forecast_data['yhat_lower'])

# forecast_data[['ds', 'yhat','yhat_exp', 'yhat_lower', 'yhat_upper']].tail()
model.plot(forecast_data)
model.plot_components(forecast_data)
model.plot_seasonality('daily')
