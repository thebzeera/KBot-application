import pickle
from fbprophet import Prophet
import numpy as np
import pandas as pd
#import matplotlib.plot as plt
##
data_points_per_day=24
tarining_data = .98

load_df = pd.read_csv('cleaned_data.csv')
load_df['ds'] = pd.to_datetime(load_df['ds'])

 # to save a copy of the original data
load_df['y_orig'] = load_df['y']
# log-transform y
# print(load_df['y_orig'],"load_dfh")
load_df['y'] = np.log(load_df['y'])
# print(load_df['y'],"load_df['y']")

#Split data from training and testing
train, test,validate = np.split(load_df, [int(tarining_data*len(load_df)), int(1*len(load_df))])
# print(train,"&&&&&&&&&&&&&&&&&&&&&&&")
# # print(len(train),len(validate),len(test))
test = pd.read_csv("test.csv")
# train.to_csv("train.csv")
model = Prophet() #instantiate Prophet
model.fit(train); #fit the model with your dataframe
# exit()
#print(len(load_df)*(1-tarining_data))
future_data = model.make_future_dataframe(periods=int(len(load_df)*(1-tarining_data)),freq='H')
# print(future_data)
# exit()
# test_set = pd.read_csv("Book1.csv")
# forcats data
# print(future_data['y'],"futuredata_yy")
forecast_data = model.predict(test)
# forecast_data = model.predict(test_set)
# exit()
forecast_data.to_csv('original.csv')
# exit()
#inverse log of yhat
forecast_data['yhat_exp']=np.exp(forecast_data['yhat'])
# forecast_data['yhat_upper_exp']=np.exp(forecast_data['yhat_upper'])
# forecast_data['yhat_lower_exp']=np.exp(forecast_data['yhat_lower'])

# forecast_data[['ds', 'yhat','yhat_exp', 'yhat_lower', 'yhat_upper']].tail()
model.plot(forecast_data)
model.plot_components(forecast_data)

s = model.update_beta()
# print(s)
fore = model.predict(test)
print(fore.to_csv("fore.csv"),"foreeeee")
# exit()
model.plot_components(fore)
# print(fore,"fore")
# print(v,"vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv")








