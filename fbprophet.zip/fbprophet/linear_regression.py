# import numpy as np
# import matplotlib.pyplot as plt
from sklearn import datasets, linear_model, metrics
#
# def estimate_coef(x, y):
#
#     X = x.transpose()
#     # number of observations/points
#     n = np.size(x)
#     Y =y.values
#     # N= n.transpose()
#     print(type(X),"iiiiiiii")
#     print(type(Y),"vghvgh")
#     # mean of x and y vector
#     m_x, m_y = np.mean(X), np.mean(y)
#     print(m_x.shape)
#     print(X * Y)
#     # exit()
#
#     # calculating cross-deviation and deviation about x
#     SS_xy = np.sum(X * Y) -n*m_x * m_y
#     # exit()
#     print("_______________________")
#     SS_xx = np.sum(x * x) - n * m_x * m_x
#     print("+++++++++++++++++++")
#
#     # calculating regression coefficients
#     b_1 = SS_xy / SS_xx
#     # b_0 = m_y - b_1 * m_x
#
#     return b_1
#
#
# # def plot_regression_line(x, y, b):
# #     # plotting the actual points as scatter plot
# #     plt.scatter(x, y, color="m",
# #                 marker="o", s=30)
# #
# #     # predicted response vector
# #     y_pred = b[0] + b[1] * x
# #
# #     # plotting the regression line
# #     plt.plot(x, y_pred, color="g")
# #
# #     # putting labels
# #     plt.xlabel('x')
# #     plt.ylabel('y')
# #
# #     # function to show plot
# #     plt.show()
# #
# #
# def main():
#     # observations
#     x = np.array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
#     y = np.array([1, 3, 2, 5, 7, 8, 8, 9, 10, 12])
#
#     # estimating coefficients
#     b = estimate_coef(x, y)
#     print(b)
#     # print("Estimated coefficients:\nb_0 = {}  \
#     # \nb_1 = {}".format(b[0], b[1]))
#
#     # plotting regression line
#     # plot_regression_line(x, y, b)
# #
# if __name__ == "__main__":
#     main()
#
def estimate_coef(x, y):

    from sklearn.model_selection import train_test_split
    # X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.4,
    #                                                     random_state=1)

    # create linear regression object
    reg = linear_model.LinearRegression()

    # train the model using the training sets
    print(x.shape)
    print(y.shape)
    reg.fit(x, y)
    inter = reg.intercept_
    # print(inter, "intercept")

    # regression coefficients
    reg = reg.coef_

    # variance = reg.score(X_test, y_test)

    # variance score: 1 means perfect prediction
    # print('Variance score: {}'.format(reg.score(X_test, y_test)))

    return reg


import matplotlib.pyplot as plt
import numpy as np
# from sklearn import datasets, linear_model, metrics
#
# # load the boston dataset
# boston = datasets.load_boston(return_X_y=False)
#
# # defining feature matrix(X) and response vector(y)
# X = boston.data
# y = boston.target
#
# # splitting X and y into training and testing sets
# from sklearn.model_selection import train_test_split
# X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.4,
# 													random_state=1)
#
# # create linear regression object
# reg = linear_model.LinearRegression()
#
# # train the model using the training sets
# print(X_train.shape)
# print(y_train.shape)
# reg.fit(X_train, y_train)
#
# # regression coefficients
# print('Coefficients: \n', reg.coef_)
#
# # variance score: 1 means perfect prediction
# print('Variance score: {}'.format(reg.score(X_test, y_test)))

# plot for residual error

# ## setting plot style
# plt.style.use('fivethirtyeight')
#
# ## plotting residual errors in training data
# plt.scatter(reg.predict(X_train), reg.predict(X_train) - y_train,
# 			color = "green", s = 10, label = 'Train data')
#
# ## plotting residual errors in test data
# plt.scatter(reg.predict(X_test), reg.predict(X_test) - y_test,
# 			color = "blue", s = 10, label = 'Test data')
#
# ## plotting line for zero residual error
# plt.hlines(y = 0, xmin = 0, xmax = 50, linewidth = 2)
#
# ## plotting legend
# plt.legend(loc = 'upper right')
#
# ## plot title
# plt.title("Residual errors")
#
# ## function to show plot
# plt.show()
