from pylab import rcParams
import pandas as pd

import numpy as np
import matplotlib.pyplot as plt
import statsmodels.api as sm
# rcParams['figure.figsize'] = 18, 8
# decomposition = sm.tsa.seasonal_decompose(y, model='additive')
# fig = decomposition.plot()
# plt.show()

import pandas as pd

df =  pd.read_csv("history.csv")
print(df)
df['ds'] = pd.to_datetime(df['ds'], errors='coerce')
i0, i1 = df['ds'].idxmin(), df['ds'].idxmax()
T = df['t'].iloc[i1] - df['t'].iloc[i0]
print(T,"Tttt")
hist_size = np.floor(
                df.shape[0] * .8)

cp_indexes = (
                    np.linspace(0, hist_size - 1, 25 + 1)
                    .round()
                    .astype(np.int)
                )
changepoints = df.iloc[cp_indexes]['ds'].tail(-1)
start=df['ds'].min()
t_scale =df['ds'].max()-start
k = (df['y_scaled'].iloc[i1] - df['y_scaled'].iloc[i0]) / T
m = df['y_scaled'].iloc[i0] - k * df['t'].iloc[i0]
changepoints_t = np.sort(np.array(
                (changepoints - start) / t_scale))
t = np.array(df['t'])
delta = np.random.normal(size=25)
S = len(changepoints_t)
d = t.max()
n_changes = np.random.poisson(S * (d - 1))
changepoint_ts_new = 1 + np.random.rand(n_changes) * (T - 1)
changepoint_ts = np.concatenate((changepoints_t,
                                         changepoint_ts_new))
def piecewise_linear(t, deltas, k, m, changepoint_ts):

    gammas = -changepoint_ts * deltas
    # Get cumulative slope and intercept at each t
    k_t = k * np.ones_like(t)
    m_t = m * np.ones_like(t)
    for s, t_s in enumerate(changepoint_ts):
        indx = t >= t_s
        k_t[indx] += deltas[s]
        m_t[indx] += gammas[s]
        v =k_t * t + m_t
    return v

obj = piecewise_linear(t, k, m, changepoint_ts)
prediction = pd.DataFrame(obj, columns=['predictions']).to_csv('prediction.csv')