from collections import OrderedDict

from numpy import ndarray
import numpy as np
from matplotlib import pyplot as plt

k = -0.02642670185399782

m = 0.6675103635486196

deltas = [ int(5.47042552e-07), int(-1.62851520e-02), int(-8.63708699e-07),
        int(-2.08160202e-02), int(-6.67008866e-03), int(-1.37508039e-06),
           int(3.09348428e-05),  int(9.25497068e-05),  int(1.75440287e-07),
           int(2.00682272e-07),  int(4.61538498e-05),  int(2.39745785e-04),
         int(2.51239378e-03),  int(7.15504166e-02),  int(2.74980445e-07),
           int(-1.06367252e-07), int(-5.46964799e-08), int(-6.53642626e-06),
           int(-4.54288573e-02), int(-1.06529629e-01), int(-5.57528544e-03),
           int(-1.33809831e-02), int(-2.99665834e-04),  int(1.38461650e-08),
           int(2.39121245e-01)]

changepoints_t = [0.03190075, 0.06380151, 0.09570226, 0.12804608 ,0.15994683, 0.19199527,
 0.2241914,  0.25609216, 0.28799291, 0.32004135, 0.35194211, 0.38384286,
 0.41574361, 0.44764437, 0.47954512, 0.51188894, 0.54393738, 0.57613351,
 0.60818195, 0.64008271, 0.67183577, 0.70373652, 0.73563728, 0.76768572,
 0.79958647]
# params = {'k': ndarray([[-0.0264267]]), 'm': ndarray([[0.66751036]]), 'delta': ndarray([[ 5.47042552e-07, -1.62851520e-02, -8.63708699e-07,
#         -2.08160202e-02, -6.67008866e-03, -1.37508039e-06,
#          3.09348428e-05,  9.25497068e-05,  1.75440287e-07,
#          2.00682272e-07,  4.61538498e-05,  2.39745785e-04,
#          2.51239378e-03,  7.15504166e-02,  2.74980445e-07,
#         -1.06367252e-07, -5.46964799e-08, -6.53642626e-06,
#         -4.54288573e-02, -1.06529629e-01, -5.57528544e-03,
#         -1.33809831e-02, -2.99665834e-04,  1.38461650e-08,
#          2.39121245e-01]]), 'sigma_obs': ndarray([[0.06685752]]), 'beta': ndarray([[-0.02527481,  0.04915305,  0.0229234 , -0.02436392, -0.00683688,
#          0.00828509, -0.1183561 , -0.16529153, -0.07068228,  0.03662862,
#         -0.00559724,  0.04012519,  0.00390656, -0.00111623, -0.07672044]]), 'trend': ndarray([[0.66751036, 0.66750646, 0.66750256, ..., 0.62922651, 0.62923717,
#         0.62924783]]), 'Y': ndarray([[0.45363896, 0.39796466, 0.39269071, ..., 0.30207856, 0.29282868,
#         0.34374934]]), 'beta_m': ndarray([[-0.,  0.,  0., -0., -0.,  0., -0., -0., -0.,  0., -0.,  0.,  0.,
#         -0., -0.]]), 'beta_a': ndarray([[-0.02527481,  0.04915305,  0.0229234 , -0.02436392, -0.00683688,
#          0.00828509, -0.1183561 , -0.16529153, -0.07068228,  0.03662862,
#         -0.00559724,  0.04012519,  0.00390656, -0.00111623, -0.07672044]])}


def piecewise_linear(t, deltas, k, m, changepoint_ts):
    """Evaluate the piecewise linear function.

    Parameters
    ----------
    t: np.ndarray of times on which the function is evaluated.
    deltas: np.ndarray of rate changes at each changepoint.
    k: Float initial rate.
    m: Float initial offset.
    changepoint_ts: np.ndarray of changepoint times.

    Returns
    -------
    Vector y(t).
    """
    # Intercept changes
    # print(type(deltas),"change point")
    # gammas = np.asarray(changepoint_ts) * np.asarray(deltas)
    gammas = changepoint_ts * deltas
    # Get cumulative slope and intercept at each t
    k_t = k * np.ones_like(t)
    m_t = m * np.ones_like(t)
    for s, t_s in enumerate(changepoint_ts):
        indx = t >= t_s
        k_t[indx] += deltas[s]
        m_t[indx] += gammas[s]
    v =k_t*t + m_t
    print(v)
    return k_t * t + m_t


def plot_forecast_component(
    m, fcst, name, ax=None, uncertainty=True, plot_cap=False, figsize=(10, 6)
):
    """Plot a particular component of the forecast.

    Parameters
    ----------
    m: Prophet model.
    fcst: pd.DataFrame output of m.predict.
    name: Name of the component to plot.
    ax: Optional matplotlib Axes to plot on.
    uncertainty: Optional boolean to plot uncertainty intervals.
    plot_cap: Optional boolean indicating if the capacity should be shown
        in the figure, if available.
    figsize: Optional tuple width, height in inches.

    Returns
    -------
    a list of matplotlib artists
    """
    artists = []
    if not ax:
        fig = plt.figure(facecolor='w', figsize=figsize)
        ax = fig.add_subplot(111)
    fcst_t = fcst['ds'].dt.to_pydatetime()
    artists += ax.plot(fcst_t, fcst[name], ls='-', c='#0072B2')
    if 'cap' in fcst and plot_cap:
        artists += ax.plot(fcst_t, fcst['cap'], ls='--', c='k')
    if m.logistic_floor and 'floor' in fcst and plot_cap:
        ax.plot(fcst_t, fcst['floor'], ls='--', c='k')
    if uncertainty:
        artists += [ax.fill_between(
            fcst_t, fcst[name + '_lower'], fcst[name + '_upper'],
            color='#0072B2', alpha=0.2)]
    ax.grid(True, which='major', c='gray', ls='-', lw=1, alpha=0.2)
    ax.set_xlabel('ds')
    ax.set_ylabel(name)
    # if name in m.component_modes['multiplicative']:
    #     ax = set_y_as_per/cent(ax)
    return artists

import pandas as pd


def fourier_series(dates, period, series_order):
    """Provides Fourier series components with the specified frequency
    and order.

    Parameters
    ----------
    dates: pd.Series containing timestamps.
    period: Number of days of the period.
    series_order: Number of components.

    Returns
    -------
    Matrix with seasonality features.
    """
    # convert to days since epoch
    t = np.array(
        (dates - pd.datetime(1970, 1, 1))
        .dt.total_seconds()
        .astype(np.float)
    ) / (3600 * 24.)
    return np.column_stack([
        fun((2.0 * (i + 1) * np.pi * t / period))
        for i in range(series_order)
        for fun in (np.sin, np.cos)
    ])

extra_regressors = OrderedDict({})
def regressor_column_matrix(seasonal_features, modes):
    """Dataframe indicating which columns of the feature matrix correspond
    to which seasonality/regressor components.

    Includes combination components, like 'additive_terms'. These
    combination components will be added to the 'modes' input.

    Parameters
    ----------
    seasonal_features: Constructed seasonal features dataframe
    modes: Dictionary with keys 'additive' and 'multiplicative' listing the
        component names for each mode of seasonality.

    Returns
    -------
    component_cols: A binary indicator dataframe with columns seasonal
        components and rows columns in seasonal_features. Entry is 1 if
        that columns is used in that component.
    modes: Updated input with combination components.
    """
    # print(seasonal_features.columns,"seasona")
    components = pd.DataFrame({
        'col': np.arange(seasonal_features.shape[1]),
        'component': [
            x.split('_delim_')[0] for x in seasonal_features.columns
        ],
    })
    print(components,"seasona")

    # Add totals additive and multiplicative components, and regressors

    for mode in ['additive', 'multiplicative']:
        components = add_group_component(
            components, mode + '_terms', modes[mode]
        )
        regressors_by_mode = [
            r for r, props in list(extra_regressors.items())
            if props['mode'] == mode
        ]
        components = add_group_component(
            components, 'extra_regressors_' + mode, regressors_by_mode)
        # Add combination components to modes
        modes[mode].append(mode + '_terms')
        modes[mode].append('extra_regressors_' + mode)

    # Convert to a binary matrix
    component_cols = pd.crosstab(
        components['col'], components['component'],
    ).sort_index(level='col')
    # Add columns for additive and multiplicative terms, if missing
    for name in ['additive_terms', 'multiplicative_terms']:
        if name not in component_cols:
            component_cols[name] = 0
    # Remove the placeholder
    component_cols.drop('zeros', axis=1, inplace=True, errors='ignore')
    # Validation
    if (
        max(component_cols['additive_terms']
        + component_cols['multiplicative_terms']) > 1
    ):
        raise Exception('A bug occurred in seasonal components.')
    # Compare to the training, if set.

    return component_cols, modes



def add_group_component( components, name, group):
    """Adds a component with given name that contains all of the components
    in group.

    Parameters
    ----------
    components: Dataframe with components.
    name: Name of new group component.
    group: List of components that form the group.

    Returns
    -------
    Dataframe with components.
    """
    new_comp = components[components['component'].isin(set(group))].copy()
    group_cols = new_comp['col'].unique()
    if len(group_cols) > 0:
        new_comp = pd.DataFrame({'col': group_cols, 'component': name})
        components = components.append(new_comp)
    return components


