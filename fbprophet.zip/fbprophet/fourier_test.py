import numpy as np
from matplotlib import pyplot as plt
import pandas as pd
import pymc3 as pm
import matplotlib.pyplot as plt
import numpy as np
import scipy.stats as st
import math
import numpy as np

def get_tau_sd(tau=None, sd=None):
    """
    Find precision and standard deviation. The link between the two
    parameterizations is given by the inverse relationship:

    .. math::
        \tau = \frac{1}{\sigma^2}

    Parameters
    ----------
    tau : array-like, optional
    sd : array-like, optional

    Results
    -------
    Returns tuple (tau, sd)

    Notes
    -----
    If neither tau nor sd is provided, returns (1., 1.)
    """
    if tau is None:
        if sd is None:
            sd = 1.
            tau = 1.
        else:
            tau = sd**-2.

    else:
        if sd is not None:
            raise ValueError("Can't pass both tau and sd")
        else:
            sd = tau**-.5

    # cast tau and sd to float in a way that works for both np.arrays
    # and pure python
    tau = 1. * tau
    sd = 1. * sd

    return np.asarray(tau), np.asarray(sd)

def Normal(mu, sd=None, tau=None):
    tau, sd = get_tau_sd(tau=None, sd=sd)
    value = -1e-6
    nd = (-tau * (value - mu) ** 2 + math.log(tau / np.pi / 2.)) / 2.,sd > 0
    print(nd)

def seasonality_model(dates, p, n, period):
    t = np.array(
        (dates - pd.datetime(1970, 1, 1))
            .dt.total_seconds()
            .astype(np.float)
    ) / (3600 * 24.)
    # print(t)

    # 2 pi n / p
    x = 2 * np.pi * np.arange(1, n + 1) / p
    # 2 pi n / p * t
    x = x * t[:, None]
    x = np.concatenate((np.cos(x), np.sin(x)), axis=1)
    end =n*2
    y =np.linspace(-1, float((n*2)/2), end)
    # print(y,"yyy")
    beta_resh = st.norm.pdf(y, 0, n)


    mu, sigma = 3., 1.  # mean and standard deviation
    beta = np.random.lognormal(mu, sigma, 2*n)
    # import numpy as np
    beta = np.asarray(beta)
    beta.reshape(1, 6)
    # print(beta.reshape(1, 20))
    # beta=beta_resh.reshape(1,len(beta_resh))
    # with pm.Model() as model:
    #     # beta = pm.Normal(f'beta_{period}', mu=0, sd=seasonality_prior_scale, shape=2 * n)
    #     beta = pm.Normal(period, mu=0, sd=p, shape=2 * n)
    #     beta = Normal( mu= 0, sd=p,tau=None)
    return x,beta



data = pd.read_csv('cleaned_data.csv', parse_dates=['ds'])
dates = data['ds']

# x_yearly, beta_yearly = seasonality_model(dates, 365.25, 10,"beta_yearlty")
# print(beta_yearly.T,"PPPP")

x_weekly, beta_weekly = seasonality_model(dates, 7, 3,'beta_weekly')

def det_seasonality_posterior(beta, x):
    return np.dot(x, beta.T)

# yearly_posterior = det_seasonality_posterior(beta_yearly, x_yearly) * data['y'].max()
# print(len(yearly_posterior),"yearly##########")
# exit()
weekly_posterior = det_seasonality_posterior(beta_weekly, x_weekly) * data['y'].max()
my_df = pd.DataFrame(data=weekly_posterior, columns=['A'])
my_df.to_csv("weekly.csv")
exit()

date = data['ds'].dt.to_pydatetime()
sunday = np.argmax(data['ds'].dt.dayofweek)
weekdays = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday']
idx_year = np.argmax(data['ds'].dt.dayofyear)
# print( idx_year )
# exit()
plt.figure(figsize=(16, 3*6))
b = 411
plt.subplot(b)

p = 0.025

plt.subplot(b + 2)
plt.title('yearly')
# print(yearly_posterior)
# exit()
# # print(weekly_posterior.shape)
# v =yearly_posterior.mean(1)
# print(v)
# print(idx_year)

plt.plot(date[idx_year: idx_year + 24], yearly_posterior[idx_year: idx_year + 24])
quant = np.quantile(yearly_posterior, [p, 1 - p], axis=0)
print(quant,"quant")
plt.fill_between(date[idx_year: idx_year + 24],
                 quant[0, idx_year: idx_year + 24], quant[1, idx_year: idx_year + 24], alpha=0.25)
plt.show()
exit()
plt.subplot(b + 3)
plt.title('weekly')
plt.plot(weekdays, weekly_posterior.mean(1)[sunday: sunday + 7])
quant = np.quantile(weekly_posterior, [p, 1 - p], axis=1)
plt.fill_between(weekdays, quant[0, sunday: sunday + 7],
                 quant[1, sunday: sunday + 7], alpha=0.25)

