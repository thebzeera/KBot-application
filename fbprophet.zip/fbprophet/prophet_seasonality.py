import pandas as pd
import  function
import numpy as np

# load_df = pd.read_csv('futurre.csv')
# load_df['ds'] = pd.to_datetime(load_df['ds'])
#
# forecast_data = function.predict_seasonal_components(load_df)
#
# cols = ['ds']
# if 'cap' in load_df:
#     cols.append('cap')
#
# df2 = pd.concat((load_df[cols], forecast_data), axis=1)
# df2.to_csv("seasonality.csv")


df2 = pd.read_csv("seasonality.csv")
df2['yhat'] = (
    df2['trend'] * (1 + 0)
    + df2['additive_terms']
)
df2['yhat_exp']=np.exp(df2['yhat'])
# df2['yhat_upper_exp']=np.exp(df2['yhat_upper'])
# df2['yhat_lower_exp']=np.exp(df2['yhat_lower'])


# print(df2[['ds', 'yhat','yhat_exp', 'yhat_lower', 'yhat_upper']].tail())
# exit()
# function.plot(forecast_data)
function.plot_components(df2)
# function.plot_seasonality('daily')



