import pymc3 as pm
import numpy as np
import pandas as pd


# m = pm.Model()

def seasonality_model( df, period='yearly', seasonality_prior_scale=10):
    if period == 'yearly':
        n = 10
        # rescale the period, as t is also scaled
        p = 365.25 / (df['ds'].max() - df['ds'].min()).days
    else:  # weekly
        n = 3
        # rescale the period, as t is also scaled
        p = 7 / (df['ds'].max() - df['ds'].min()).days
    x = fourier_series(df['ds'], p, n)
    with pm.Model() as model:
        beta = pm.Normal(f'beta_{period}', mu=0, sd=seasonality_prior_scale, shape=2 * n)

        print(type(beta),"type")
    # with pm.Model() as model:
    #     trace = pm.sample(500)
        # exit()
    return x, beta


def fourier_series(dates, p=365.25, n=10):

    t = np.array(
        (dates - pd.datetime(1970, 1, 1))
            .dt.total_seconds()
            .astype(np.float)
    ) / (3600 * 24.)
    # print(t)

    # 2 pi n / p
    x = 2 * np.pi * np.arange(1, n + 1) / p
    # 2 pi n / p * t
    x = x * t[:, None]
    x = np.concatenate((np.cos(x), np.sin(x)), axis=1)
    return x


data = pd.read_csv('cleaned_data.csv', parse_dates=['ds'])
dates = data['ds']

x = np.linspace(0, 5, 20)
# print(dates)
# t = np.array(
#         (dates - pd.datetime(1970, 1, 1))
#             .dt.total_seconds()
#             .astype(np.float)
#     ) / (3600 * 24.)
x_yearly, beta_yearly = seasonality_model(data, 'yearly',10)
print(beta_yearly.T)

# yearly_posterior = det_seasonality_posterior(beta_yearly, x_yearly) * data['y'].max()