import pickle
from fbprophet import Prophet
import numpy as np
import pandas as pd

from matplotlib import pyplot as plt

temp1 = np.random.rand(2, 3)

A = [[1, 4 ,6],
     [5, 8 , 7],
     [3, 5 , 5]]

B = [[1],
    [-5],
     [2]]

c=[[-7],
   [-11],
   [-11]]

# print(np.matmul(A,B))

# newA=np.matmul(temp1,A)
# newc=np.matmul(temp1,c)

Ainveres = np.linalg.inv(A)

newb = np.matmul(Ainveres,c)

print(newb)
print(np.matmul(A,newb))

