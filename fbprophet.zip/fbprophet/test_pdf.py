#
# import warnings
# import itertools
# import numpy as np
# import matplotlib.pyplot as plt
# warnings.filterwarnings("ignore")
# plt.style.use('fivethirtyeight')
# import pandas as pd
# import statsmodels.api as sm
# import matplotlib
#
# matplotlib.rcParams['axes.labelsize'] = 14
# matplotlib.rcParams['xtick.labelsize'] = 12
# matplotlib.rcParams['ytick.labelsize'] = 12
# matplotlib.rcParams['text.color'] = 'k'
#
# df = pd.read_excel("Sample - Superstore.csv")
# furniture = df.loc[df['Category'] == 'Furniture']
#
# furniture['Order Date'].min()
#
# furniture['Order Date'].max()
#
# cols = ['Row ID', 'Order ID', 'Ship Date', 'Ship Mode', 'Customer ID', 'Customer Name', 'Segment', 'Country', 'City', 'State', 'Postal Code', 'Region', 'Product ID', 'Category', 'Sub-Category', 'Product Name', 'Quantity', 'Discount', 'Profit']
# furniture.drop(cols, axis=1, inplace=True)
# furniture = furniture.sort_values('Order Date')
#
# furniture.isnull().sum()
#
# furniture = furniture.groupby('Order Date')['Sales'].sum().reset_index()
#
# furniture = furniture.set_index('Order Date')
# y = furniture['Sales'].resample('MS').mean()
# print(y,"yyyyy")


# from pylab import rcParams
# rcParams['figure.figsize'] = 18, 8
#
# decomposition = sm.tsa.seasonal_decompose(y, model='additive')

import pandas as pd
import matplotlib.pyplot as plt
df = pd.read_csv("cleaned_data.csv")

diet = df['y']
# df[['y']].plot(figsize=(20, 10), linewidth=5, fontsize=20)
# plt.xlabel('Year', fontsize=20);
# plt.show()
# exit()
diet.rolling(25).mean().plot(figsize=(20, 10), linewidth=5, fontsize=20)
plt.xlabel('Year', fontsize=20)
plt.show()