﻿Run Initialize.py
Change name of crawlfile in Initialize.py
Run Pymongotestd.py
