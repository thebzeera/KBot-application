input_list = ["audit", "audit_itext", "audit_orginal"]
var = input("Please select audit version: \n  "+input_list[0]+'\n  '+ input_list[1]+'\n  '+ input_list[2]+'\n')
print("You entered " + str(var))