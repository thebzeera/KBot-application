import tika
from tika import parser
import os
import requests
import glob
from os import path

os.environ['NO_PROXY'] = 'localhost'
session = requests.Session()
session.trust_env = False
# tika.TikaClientOnly = True
# tika.tika.TIKA_SERVER_ENDPOINT = 'http://127.0.0.1:9998'
# tika.tika.TIKA_PATH = 'C:\\installs\\pylibs\\tika\\server'
# tika.tika.TIKA_LOG_PATH = 'C:\\installs\\pylibs\\tika\\logs'
# parsed = parser.from_file('C:\\Documents\\forBot\\1.CMS Fusion Introduction.docx')
# parsed = parser.from_file('C:\\Documents\\forBot\\j2m-shareable.jpg')
# print(parsed["content"])
# print(parsed["metadata"])
import os

basepath = path.dirname(__file__)
trim = basepath.split("dataSetup")[0]
full_path = trim + 'Server/cluster/data_docx'
file_list = []
for root, dirs, files in os.walk(full_path):
    file_list.append(root)

file = []
for f in file_list:
    for filename in os.listdir(f):
        add_slash = os.path.join(str(f), '')
        file_path = add_slash + filename
        file.append(file_path)
# print(file)
i = 0
for name in file:

    if os.path.isfile(name):

        ext = [".doc", ".docx", ".pdf", ".ppt", ".pptx", ".xls", ".xlsx"]

        genPath = trim + "Server/cluster/docx_parsed"
        try:
            parsed = parser.from_file(name)
            print(name)
            fh = open(genPath + '/' + str(i + 1) + '.txt', "w", encoding='utf8')
            fh.write(name + parsed["content"])
            fh.close()
            i += 1
        except:
            print("exception for : " + name)
